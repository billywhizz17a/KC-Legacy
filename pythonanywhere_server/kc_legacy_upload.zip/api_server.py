"""
KC Legacy Valeting - Backend API Server
Provides REST endpoints for bookings and images so external clients
(admin program, social media app, etc.) can connect independently.

Run: python api_server.py
The API will start on http://localhost:5000
"""

import os
import json
import uuid
import datetime
from flask import Flask, jsonify, send_file, request, send_from_directory, abort
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Allow cross-origin requests from the desktop clients

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEXT_UPLOADS_DIR = os.path.join(BASE_DIR, "uploads", "text")
IMAGE_UPLOADS_DIR = os.path.join(BASE_DIR, "uploads", "images")
# Static customer website files (index.html, app.js, style.css, etc.)
WWW_DIR = os.path.join(BASE_DIR, "www")

os.makedirs(TEXT_UPLOADS_DIR, exist_ok=True)
os.makedirs(IMAGE_UPLOADS_DIR, exist_ok=True)


# ── Customer Website (served at root) ──
@app.route("/", methods=["GET"])
def home():
    index_path = os.path.join(WWW_DIR, "index.html")
    if os.path.exists(index_path):
        return send_from_directory(WWW_DIR, "index.html")
    return jsonify({
        "service": "KC Legacy Valeting",
        "message": "Website files not found. Upload the customer_app/www files to the 'www' folder.",
        "api_health": "/api/health"
    })


@app.route("/<path:filename>", methods=["GET"])
def serve_static(filename):
    """Serve customer website assets (app.js, style.css, images, manifest, etc.)."""
    # Never hijack API routes
    if filename.startswith("api/"):
        abort(404)
    file_path = os.path.join(WWW_DIR, filename)
    if os.path.exists(file_path) and os.path.isfile(file_path):
        return send_from_directory(WWW_DIR, filename)
    abort(404)


# ── Health Check ──
@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "KC Legacy Valeting API"})


# ── Bookings ──
@app.route("/api/bookings", methods=["GET"])
def list_bookings():
    files = sorted([f for f in os.listdir(TEXT_UPLOADS_DIR) if f.endswith(".txt")])
    bookings = []
    for f in files:
        filepath = os.path.join(TEXT_UPLOADS_DIR, f)
        try:
            with open(filepath, "r", encoding="utf-8") as file:
                content = file.read()
        except Exception as e:
            content = f"Error reading file: {e}"
        bookings.append({
            "filename": f,
            "size": os.path.getsize(filepath),
            "content": content
        })
    return jsonify({"count": len(bookings), "bookings": bookings})


@app.route("/api/bookings/<filename>", methods=["GET"])
def get_booking(filename):
    filepath = os.path.join(TEXT_UPLOADS_DIR, filename)
    if not os.path.exists(filepath):
        return jsonify({"error": "Booking not found"}), 404
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
        return jsonify({"filename": filename, "content": content})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/bookings", methods=["POST"])
def create_booking():
    try:
        data = request.get_json() or {}

        name = data.get("name", "").strip()
        phone = data.get("phone", "").strip()
        email = data.get("email", "").strip()
        car_make = data.get("carMake", "").strip()
        car_reg = data.get("carReg", "").strip()
        booking_date = data.get("date", "").strip()
        package = data.get("package", "")
        package_price = data.get("packagePrice", 0)
        addons = data.get("addons", [])
        special_requests = data.get("specialRequests", "")
        total_price = data.get("totalPrice", package_price)

        if not name or not phone or not car_make:
            return jsonify({"error": "Name, phone and car details are required"}), 400

        booking_id = str(uuid.uuid4())[:8]
        filename = f"booking_{booking_id}_{name.replace(' ', '_')}.txt"
        file_path = os.path.join(TEXT_UPLOADS_DIR, filename)

        # Handle both formats: list of dicts ({name, price}) from the customer
        # app, and list of plain strings from the Streamlit app.
        def _format_addon(a):
            if isinstance(a, dict):
                return f"  - {a.get('name', 'Add-on')} (+£{a.get('price', 0)})"
            return f"  - {a}"
        addons_str = "\n".join([_format_addon(a) for a in addons]) if addons else "  None"

        booking_content = f"""=============================================
             KC LEGACY VALETING BOOKING
=============================================
Booking ID: {booking_id}
Submission Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
----------------------------------------------
CUSTOMER INFORMATION:
Name: {name}
Phone: {phone}
Email: {email}

VEHICLE & PACKAGE DETAILS:
Vehicle: {car_make}
Registration: {car_reg or 'N/A'}
Selected Package: {package} (From £{package_price})
Scheduled Date: {booking_date}

ADD-ONS INCLUDED:
{addons_str}

SPECIAL REQUESTS:
{special_requests or 'None'}

ESTIMATED TOTAL: £{total_price}
=============================================
"""
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(booking_content)

        return jsonify({
            "success": True,
            "bookingId": booking_id,
            "filename": filename,
            "message": "Booking confirmed"
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/bookings/<filename>", methods=["DELETE"])
def delete_booking(filename):
    filepath = os.path.join(TEXT_UPLOADS_DIR, filename)
    if not os.path.exists(filepath):
        return jsonify({"error": "Booking not found"}), 404
    try:
        os.remove(filepath)
        return jsonify({"message": f"{filename} deleted successfully"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Images ──
@app.route("/api/images", methods=["GET"])
def list_images():
    files = sorted([f for f in os.listdir(IMAGE_UPLOADS_DIR)
                    if f.lower().endswith((".png", ".jpg", ".jpeg"))])
    images = []
    for f in files:
        filepath = os.path.join(IMAGE_UPLOADS_DIR, f)
        images.append({
            "filename": f,
            "size": os.path.getsize(filepath),
            "url": f"/api/images/{f}"
        })
    return jsonify({"count": len(images), "images": images})


@app.route("/api/images/<filename>", methods=["GET"])
def get_image(filename):
    filepath = os.path.join(IMAGE_UPLOADS_DIR, filename)
    if not os.path.exists(filepath):
        return jsonify({"error": "Image not found"}), 404
    return send_file(filepath)


@app.route("/api/images/<filename>", methods=["DELETE"])
def delete_image(filename):
    filepath = os.path.join(IMAGE_UPLOADS_DIR, filename)
    if not os.path.exists(filepath):
        return jsonify({"error": "Image not found"}), 404
    try:
        os.remove(filepath)
        return jsonify({"message": f"{filename} deleted successfully"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Banner ──
@app.route("/api/banner", methods=["GET"])
def get_banner():
    candidates = [
        os.path.join(IMAGE_UPLOADS_DIR, "hero", "hero.png"),
        os.path.join(IMAGE_UPLOADS_DIR, "header2.jpg"),
        os.path.join(IMAGE_UPLOADS_DIR, "favicon.png"),
    ]
    for path in candidates:
        if os.path.exists(path):
            return send_file(path)
    return jsonify({"error": "No banner image found"}), 404


if __name__ == "__main__":
    print("=" * 55)
    print(" KC Legacy Valeting API Server")
    print("=" * 55)
    print("Base URL: http://localhost:5000")
    print("Endpoints:")
    print("  GET    /api/health")
    print("  GET    /api/bookings")
    print("  GET    /api/bookings/<filename>")
    print("  DELETE /api/bookings/<filename>")
    print("  GET    /api/images")
    print("  GET    /api/images/<filename>")
    print("  DELETE /api/images/<filename>")
    print("  GET    /api/banner")
    print("=" * 55)
    app.run(host="0.0.0.0", port=5000, debug=False)
